const video=document.getElementById("video"), canvas=document.getElementById("overlay"), ctx=canvas.getContext("2d");
const statusEl=document.getElementById("status"), pred=document.getElementById("prediction"), conf=document.getElementById("confidence");
const sentence=document.getElementById("sentence"), speakBtn=document.getElementById("speak"), labelInput=document.getElementById("label");
const collectBtn=document.getElementById("collect"), finishBtn=document.getElementById("finish"), trainStatus=document.getElementById("trainStatus"), labelsEl=document.getElementById("labels");
let latest=null,lastText="",stableCount=0,lastSpoken="";
let samples=JSON.parse(localStorage.getItem("islSamples")||"[]");
let collecting=false,currentLabel="",currentSamples=0;

function norm(lm){
 const wrist=lm[0], scale=Math.hypot(lm[9].x-wrist.x,lm[9].y-wrist.y)||1;
 return lm.flatMap(p=>[(p.x-wrist.x)/scale,(p.y-wrist.y)/scale,(p.z-wrist.z)/scale]);
}
function dist(a,b){let s=0;for(let i=0;i<a.length;i++){let d=a[i]-b[i];s+=d*d}return Math.sqrt(s/a.length)}
function classify(v){
 if(!samples.length) return null;
 const by={}; for(const s of samples){const d=dist(v,s.v); if(!by[s.label]||d<by[s.label])by[s.label]=d}
 const ranked=Object.entries(by).sort((a,b)=>a[1]-b[1]); if(!ranked.length)return null;
 const [lab,d]=ranked[0]; const confidence=Math.max(0,Math.min(99,100*(1-d/1.2)));
 return {lab,confidence,d};
}
function renderLabels(){
 const counts={};samples.forEach(s=>counts[s.label]=(counts[s.label]||0)+1);
 labelsEl.innerHTML=Object.entries(counts).map(([k,v])=>`<span class="tag">${k}: ${v}</span>`).join("")||"No trained signs yet.";
}
renderLabels();

const hands=new Hands({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}`});
hands.setOptions({maxNumHands:1,modelComplexity:1,minDetectionConfidence:.6,minTrackingConfidence:.6});
hands.onResults(r=>{
 canvas.width=video.videoWidth;canvas.height=video.videoHeight;ctx.clearRect(0,0,canvas.width,canvas.height);
 if(!r.multiHandLandmarks?.length){latest=null;pred.textContent="Hand not detected";conf.textContent="Confidence: —";return}
 const lm=r.multiHandLandmarks[0]; latest=norm(lm);
 ctx.fillStyle="#00ff88"; for(const p of lm){ctx.beginPath();ctx.arc(p.x*canvas.width,p.y*canvas.height,5,0,7);ctx.fill()}
 if(collecting && currentLabel){
   samples.push({label:currentLabel,v:latest}); currentSamples++;
   trainStatus.textContent=`Collecting "${currentLabel}": ${currentSamples} samples`;
 }
 const out=classify(latest);
 if(out){pred.textContent=out.lab;conf.textContent=`Confidence: ${out.confidence.toFixed(0)}%`;
   if(out.lab===lastText)stableCount++;else{lastText=out.lab;stableCount=1}
   if(stableCount===12){sentence.textContent=(sentence.textContent+" "+out.lab).trim();speakBtn.disabled=false}
 }
});
let camera;
document.getElementById("start").onclick=async()=>{
 try{
  const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"},audio:false});video.srcObject=stream;
  statusEl.textContent="Camera चालू • हात camera मध्ये ठेवा";
  camera=new Camera(video,{onFrame:async()=>await hands.send({image:video}),width:640,height:480});camera.start();
 }catch(e){statusEl.textContent="Camera permission द्या. HTTPS आवश्यक आहे.";console.error(e)}
};
collectBtn.onclick=()=>{
 if(!labelInput.value.trim()){alert("पहिले sign चे नाव लिहा.");return}
 currentLabel=labelInput.value.trim().toUpperCase();collecting=true;currentSamples=0;
 trainStatus.textContent=`Collecting "${currentLabel}"... प्रत्येक click = 1 sample`;
};
finishBtn.onclick=()=>{
 collecting=false;
 localStorage.setItem("islSamples",JSON.stringify(samples));renderLabels();
 trainStatus.innerHTML=`<span class="good">${currentLabel||"Sign"} saved. Total samples: ${samples.length}</span>`;
 currentLabel="";
};
speakBtn.onclick=()=>{if(sentence.textContent)speechSynthesis.speak(new SpeechSynthesisUtterance(sentence.textContent))}
document.getElementById("clear").onclick=()=>{sentence.textContent="";pred.textContent="—";conf.textContent="Confidence: —";stableCount=0};
if("serviceWorker" in navigator)navigator.serviceWorker.register("sw.js");
