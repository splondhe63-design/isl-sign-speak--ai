# ISL SignSpeak AI — Mobile PWA

This is a working prototype for an Indian Sign Language (ISL) real-time translator.

## Important
The app uses MediaPipe Hands to extract hand landmarks and a simple nearest-sample classifier. It does NOT ship with a validated ISL dataset. Therefore you must collect representative ISL samples in the app before recognition becomes useful.

## Run
Use any HTTPS static hosting service. Camera access requires HTTPS (localhost is also allowed).

1. Open the site on Android Chrome.
2. Allow camera permission.
3. Start Camera.
4. Enter a sign label, e.g. HELLO.
5. Press Collect sample and capture around 20–30 varied samples of the same sign.
6. Press Finish sign.
7. Repeat for THANK YOU, YES, NO, HELP, etc.
8. The app stores samples in localStorage on the phone.
9. When a trained sign is recognized, it appears as text; Speak reads the sentence aloud.

## Install
Android Chrome → menu (⋮) → Add to Home screen / Install app.

## For a competition-grade version
Replace the sample-based classifier with a validated ISL dataset and a trained temporal model for dynamic signs. Add dataset consent, signer diversity, lighting/background variation, accuracy/F1/confusion-matrix evaluation, and offline model inference.
